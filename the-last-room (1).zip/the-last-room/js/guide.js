/* THE LAST ROOM - picture-based guidance: icon badges on things you can use, an arrow to the current goal (with an edge pointer when it is
   off screen), an objective icon in the HUD and number / colour / symbol chips for notes. Replaces most of the need to read text. */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {}, U = TLR.U, TAU = Math.PI * 2;
  const COL = { pick: '#ffd36b', note: '#f3ead0', eye: '#9fe7ff', puzzle: '#7ae7ff', lock: '#ffa05a', switch: '#7dff9a', portal: '#c58cff', door: '#ffffff', audio: '#8de0c9' };
  /* vector icons, drawn around (0,0) in a box of radius r */
  const IC = {
    pick(c, r) { c.beginPath(); c.arc(0, r * .22, r * .36, 0, TAU); c.fill(); for (let i = -1.5; i <= 1.5; i++) { c.beginPath(); c.roundRect ? c.roundRect(i * r * .26 - r * .09, -r * .62 + Math.abs(i) * r * .1, r * .18, r * .62, r * .09) : c.rect(i * r * .26 - r * .09, -r * .62, r * .18, r * .62); c.fill(); } c.save(); c.rotate(-.8); c.fillRect(-r * .68, r * .04, r * .4, r * .17); c.restore(); },
    note(c, r) { c.beginPath(); c.moveTo(-r * .42, -r * .6); c.lineTo(r * .2, -r * .6); c.lineTo(r * .46, -r * .34); c.lineTo(r * .46, r * .6); c.lineTo(-r * .42, r * .6); c.closePath(); c.fill(); c.fillStyle = 'rgba(10,8,18,.85)'; for (let i = 0; i < 3; i++) c.fillRect(-r * .28, -r * .2 + i * r * .27, r * (.56 - i % 2 * .18), r * .1); },
    eye(c, r) { c.beginPath(); c.moveTo(-r * .72, 0); c.quadraticCurveTo(0, -r * .85, r * .72, 0); c.quadraticCurveTo(0, r * .85, -r * .72, 0); c.fill(); c.fillStyle = 'rgba(10,8,18,.9)'; c.beginPath(); c.arc(0, 0, r * .3, 0, TAU); c.fill(); },
    puzzle(c, r) { c.fillRect(-r * .5, -r * .38, r, r * .88); c.beginPath(); c.arc(0, -r * .5, r * .22, 0, TAU); c.fill(); c.beginPath(); c.arc(r * .55, r * .05, r * .2, 0, TAU); c.fill(); c.fillStyle = 'rgba(10,8,18,.85)'; c.beginPath(); c.arc(-r * .5, r * .05, r * .2, 0, TAU); c.fill(); },
    lock(c, r) { c.fillRect(-r * .5, -r * .08, r, r * .72); c.lineWidth = r * .2; c.beginPath(); c.arc(0, -r * .1, r * .32, Math.PI, 0); c.stroke(); c.fillStyle = 'rgba(10,8,18,.9)'; c.beginPath(); c.arc(0, r * .22, r * .12, 0, TAU); c.fill(); c.fillRect(-r * .05, r * .22, r * .1, r * .26); },
    switch(c, r) { c.fillRect(-r * .6, r * .32, r * 1.2, r * .26); c.save(); c.rotate(-.55); c.fillRect(-r * .09, -r * .75, r * .18, r * 1.1); c.beginPath(); c.arc(0, -r * .75, r * .2, 0, TAU); c.fill(); c.restore(); },
    portal(c, r) { c.lineWidth = r * .2; c.beginPath(); for (let a = 0; a < 11; a += .25) { const rr = r * (.08 + a * .06); c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); } c.stroke(); },
    door(c, r) { c.fillRect(-r * .55, -r * .65, r * .7, r * 1.3); c.fillStyle = 'rgba(10,8,18,.9)'; c.fillRect(-r * .42, -r * .52, r * .44, r * 1.04); c.fillStyle = c.strokeStyle; c.beginPath(); c.moveTo(r * .12, -r * .32); c.lineTo(r * .72, 0); c.lineTo(r * .12, r * .32); c.closePath(); c.fill(); },
    audio(c, r) { c.beginPath(); c.moveTo(-r * .55, -r * .22); c.lineTo(-r * .2, -r * .22); c.lineTo(r * .15, -r * .55); c.lineTo(r * .15, r * .55); c.lineTo(-r * .2, r * .22); c.lineTo(-r * .55, r * .22); c.closePath(); c.fill(); c.lineWidth = r * .14; c.beginPath(); c.arc(r * .1, 0, r * .45, -.8, .8); c.stroke(); }
  };
  /* every digit has its own colour + symbol so number codes can be matched by picture */
  const DG = [['moon', '#8fb3ff'], ['sun', '#ffd24a'], ['star', '#ff9ad5'], ['leaf', '#5fe08a'], ['flame', '#ff7a4a'], ['drop', '#4ad8ff'], ['bolt', '#ffe84a'], ['crown', '#c58cff'], ['eye', '#ff6a6a'], ['gear', '#d0d6e0']];
  const Guide = TLR.Guide = {
    /* picture tile for one digit: coloured rounded square, symbol, small digit in the corner */
    digit(d, px) {
      const i = +d, cv = document.createElement('canvas'), z = px || 56; cv.width = cv.height = z * 2; cv.className = 'dtile'; cv.style.width = cv.style.height = z + 'px';
      const c = cv.getContext('2d'); c.scale(2, 2); const col = DG[i][1];
      c.fillStyle = 'rgba(12,9,22,.9)'; c.strokeStyle = col; c.lineWidth = 3; c.beginPath(); c.roundRect ? c.roundRect(2, 2, z - 4, z - 4, 10) : c.rect(2, 2, z - 4, z - 4); c.fill(); c.stroke();
      U.glyph(c, DG[i][0], z / 2, z / 2 - 1, z * .3, col, 3);
      c.fillStyle = col; c.font = 'bold ' + Math.round(z * .26) + 'px monospace'; c.textAlign = 'right'; c.textBaseline = 'alphabetic'; c.fillText(String(i), z - 7, z - 6);
      return cv;
    },
    seen: {},
    seenNote(o) { return o.k === 'note' && (this.seen[TLR.Game.L.id + ':' + o.x] || (o.itemId && TLR.Inv.count(o.itemId) > 0)); },
    markSeen(o) { if (o && o.k === 'note') { this.seen[TLR.Game.L.id + ':' + o.x] = 1; this.tt = 0; } },
    kindOf(o) { if (o.k === 'note') return o.kind2 === 'inspect' || o.kind2 === 'photo' ? 'eye' : o.kind2 === 'audio' ? 'audio' : 'note'; return IC[o.k] ? o.k : 'pick'; },
    /* round badge with an icon; used in the world, at the screen edge and in the HUD */
    badge(c, kind, x, y, r, a) {
      const col = COL[kind] || '#fff'; c.save(); c.translate(x, y); c.globalAlpha = a == null ? 1 : a;
      c.fillStyle = 'rgba(12,9,22,.82)'; c.beginPath(); c.arc(0, 0, r, 0, TAU); c.fill(); c.strokeStyle = col; c.lineWidth = Math.max(1.3, r * .13); c.stroke();
      c.fillStyle = col; c.strokeStyle = col; (IC[kind] || IC.pick)(c, r * .62); c.restore();
    },
    /* which objects solve the current objective step */
    targets() {
      const G = TLR.Game, L = G.L; if (!L) return [];
      const step = G.objective(), Inv = TLR.Inv, vis = G.vis, done = o => G.isDone(o) || Guide.seenNote(o);
      const owns = id => Inv.count(id) > 0;
      const gives = (o, id) => (o.k === 'pick' && o.item && o.item.id === id) || (o.item && o.item.id === id) || [].concat(o.give || []).some(q => q && q.id === id);
      const need = (flag, d) => {
        if (d > 3 || !flag) return [];
        let res = [];
        if (flag.indexOf('have:') === 0) {
          const id = flag.split(':')[1]; if (owns(id)) return [];
          res = G.objs.filter(o => vis(o) && !done(o) && gives(o, id));
          if (!res.length) { const r = Inv.recipes.find(r => r.out.id === id && r.lv === L.id); if (r) res = need('have:' + r.a + ':1', d + 1).concat(need('have:' + r.b + ':1', d + 1)); }
        } else {
          res = G.objs.filter(o => vis(o) && !done(o) && o.k !== 'cp' && [].concat(o.set || []).indexOf(flag) >= 0);
          if (!res.length) { const r = Inv.recipes.find(r => r.set === flag && r.lv === L.id); if (r) res = need('have:' + r.a + ':1', d + 1).concat(need('have:' + r.b + ':1', d + 1)); }
        }
        return res;
      };
      let list = step[0] ? need(step[0], 0) : [];
      if (!step[0]) list = G.objs.filter(o => o.k === 'door' && vis(o));
      return list;
    },
    /* pick the nearest target, or the portal that leads towards it */
    pick() {
      const G = TLR.Game, p = G.p, list = this.targets(); if (!list.length) return null;
      let best = null, bd = 1e9;
      for (const o of list) { const d = Math.abs(o.x - p.x); if (d < bd) { bd = d; best = o; } }
      if (best && (best.x < p.z0 - 1 || best.x > p.z1 + 1)) {
        const zone = G.zones.find(z => best.x >= z[0] && best.x <= z[1]);
        const por = G.objs.find(o => o.k === 'portal' && G.vis(o) && o.x >= p.z0 && o.x <= p.z1 && zone && o.to && o.to[0] >= zone[0] && o.to[0] <= zone[1]);
        if (por) return por;
      }
      return best;
    },
    update(dt) {
      const G = TLR.Game; this.idle = (this.idle || 0) + dt; const hb = document.getElementById('hud-hint'); if (hb) hb.classList.toggle('nudge', this.idle > 40); this.tt = (this.tt || 0) - dt; if (this.tt > 0) return; this.tt = .25;
      const t = this.pick(), id = t ? t.id || t.x : null;
      if (id !== this.tid) { this.tid = id; this.tgt = t; this.hud(); } else this.tgt = t;
    },
    hud() {
      const cv = document.getElementById('obj-ico'); if (!cv) return; const G = TLR.Game, on = (TLR.Save.settings.guide || 'on') !== 'off', t = on && G.mode === 'play' ? (this.tgt || this.pick()) : null;
      cv.style.display = t ? 'block' : 'none'; if (!t) return; const c = cv.getContext('2d'), w = cv.width; c.clearRect(0, 0, w, w);
      const item = t.item || [].concat(t.give || [])[0];
      if (item && item.type && t.k === 'pick' || item && item.type && t.k !== 'note') { this.badge(c, this.kindOf(t), w / 2, w / 2, w / 2 - 2); try { const ic = U.itemCanvas(item); c.drawImage(ic, w * .2, w * .2, w * .6, w * .6); } catch (e) { } }
      else this.badge(c, this.kindOf(t), w / 2, w / 2, w / 2 - 2);
    },
    /* world markers + goal beacon + edge pointer. c must have the world transform (camera) applied. */
    draw(c, s) {
      const G = TLR.Game, cam = G.cam, t = G.t, VW = G.view.w, VH = G.view.h, on = (TLR.Save.settings.guide || 'on') !== 'off', tg = this.tgt, beacon = G.beacon > 0;
      c.save(); c.setTransform(s, 0, 0, s, -cam.x * s, -cam.y * s);
      for (const o of G.objs) {
        if (o.k === 'cp' || !G.vis(o) || G.isDone(o) || this.seenNote(o) || o.x < cam.x - 20 || o.x > cam.x + VW + 20) continue;
        if (o.k === 'door' && !(o.need || []).every(G.flag)) continue;
        const isT = tg === o && (on || beacon), usable = (!o.need || o.need.every(G.flag)) && !(o.k === 'lock' && o.key && TLR.Inv.count(o.key) < (o.n || 1));
        if (G.near === o && !isT) continue;
        const top = o._y - (o.k === 'door' ? 122 : 66) - (o.oy || 0) * .3, bob = Math.sin(t * 2.4 + o.x) * 2.2, r = isT ? 15 : 11.5;
        this.badge(c, this.kindOf(o), o.x, top + bob, r, isT ? 1 : usable ? .85 : .38);
        if (isT) { const k = (t * 1.1) % 1; c.strokeStyle = 'rgba(255,224,130,' + (.7 * (1 - k)) + ')'; c.lineWidth = 2; c.beginPath(); c.arc(o.x, top + bob, r + 3 + k * 12, 0, TAU); c.stroke(); const ay = top + bob - r - 9 + Math.abs(Math.sin(t * 4)) * 5; c.fillStyle = '#ffe08a'; c.beginPath(); c.moveTo(o.x - 7, ay - 9); c.lineTo(o.x + 7, ay - 9); c.lineTo(o.x, ay + 1); c.closePath(); c.fill(); }
      }
      c.restore();
      /* off-screen pointer at the edge of the view */
      if (tg && (on || beacon) && (tg.x < cam.x + 10 || tg.x > cam.x + VW - 10)) {
        const left = tg.x < cam.x, ex = left ? 28 : VW - 28, ey = Math.max(84, Math.min(VH - 110, tg._y - 50 - cam.y)), pul = 1 + Math.sin(t * 5) * .08;
        c.save(); c.setTransform(s, 0, 0, s, 0, 0); c.translate(ex, ey); c.scale(pul, pul);
        c.fillStyle = '#ffe08a'; c.beginPath(); const d = left ? -1 : 1; c.moveTo(d * 25, 0); c.lineTo(d * 15, -9); c.lineTo(d * 15, 9); c.closePath(); c.fill();
        this.badge(c, this.kindOf(tg), 0, 0, 14, 1); c.restore();
      }
    },
    /* ---- note clues: numbers, colours and symbols ---- */
    tokens(text) {
      const T = TLR.I18N.t, out = [], taken = [];
      const free = (a, b) => !taken.some(q => a < q[1] && b > q[0]);
      const push = (a, b, o) => { if (free(a, b)) { taken.push([a, b]); o.a = a; o.b = b; out.push(o); } };
      const low = text.toLowerCase();
      const COLORS = [['red', '#ff5a5a'], ['green', '#46e078'], ['blue', '#5a9bff'], ['violet', '#c58cff'], ['purple', '#c58cff'], ['yellow', '#ffe14a'], ['gold', '#ffd36b'], ['লাল', '#ff5a5a'], ['সবুজ', '#46e078'], ['নীল', '#5a9bff'], ['বেগুনি', '#c58cff'], ['হলুদ', '#ffe14a'], ['সোনালি', '#ffd36b']];
      for (const [w, col] of COLORS) { let i = -1; while ((i = low.indexOf(w, i + 1)) >= 0) { const okL = !/[a-z]/.test(low.charAt(i - 1) || ' ') || !/[a-z]/.test(w), okR = !/[a-z]/.test(low.charAt(i + w.length) || ' ') || !/[a-z]/.test(w); if (okL && okR) push(i, i + w.length, { kind: 'col', col }); } }
      for (const key of Object.keys(U.GNAME)) for (const w of [U.GNAME[key], T(U.GNAME[key])]) { const lw = w.toLowerCase(); let i = -1; while ((i = low.indexOf(lw, i + 1)) >= 0) push(i, i + lw.length, { kind: 'glyph', key }); }
      const re = /\d+(?::\d+)?/g; let m; while ((m = re.exec(text))) { const pre = text.slice(Math.max(0, m.index - 14), m.index); if (/(p\.|day|level|room|locker|manhole|outfall|ch|manual p\.|পৃ\.|দিন|স্তর|ঘর|লকার|ম্যানহোল|মুখ|age|বয়স|years|বছর)\s*$/i.test(pre)) continue; push(m.index, m.index + m[0].length, { kind: 'num', v: m[0] }); }
      return out.sort((x, y) => x.a - y.a);
    },
    chip(tok) {
      const e = document.createElement('span'); e.className = 'chip ' + tok.kind;
      if (tok.kind === 'num') { e.className = 'chip numg'; String(tok.v).split('').forEach(ch => { if (/\d/.test(ch)) e.append(Guide.digit(ch, 44)); else { const sp = document.createElement('span'); sp.textContent = ch; sp.className = 'sep'; e.append(sp); } }); }
      else if (tok.kind === 'col') { e.style.background = tok.col; e.style.borderColor = tok.col; }
      else { const cv = U.mk(64, 64), c = cv.getContext('2d'); U.glyph(c, tok.key, 32, 32, 22, '#e8dcff', 3.2); cv.className = 'chip-cv'; e.append(cv); }
      return e;
    },
    /* fills the note paragraph with highlighted words and returns a strip of big picture chips */
    decorate(p, text) {
      const toks = this.tokens(text); p.textContent = ''; let pos = 0;
      for (const tk of toks) { if (tk.a > pos) p.append(text.slice(pos, tk.a)); const sp = document.createElement('span'); sp.className = 'hl hl-' + tk.kind; sp.textContent = text.slice(tk.a, tk.b); if (tk.kind === 'col') sp.style.color = tk.col; p.append(sp); pos = tk.b; }
      if (pos < text.length) p.append(text.slice(pos));
      if (!toks.length || toks.length > 14) return null;
      const strip = document.createElement('div'); strip.className = 'clue-strip'; toks.forEach(tk => strip.append(this.chip(tk))); return strip;
    }
  };
})(window);
