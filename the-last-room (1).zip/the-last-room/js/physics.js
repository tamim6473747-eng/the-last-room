/* THE LAST ROOM - physics: ground, one-way platforms (static + moving), stair stepping, zones, delta-time integration */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {};
  const Physics = TLR.Physics = {
    GRAV: 1500, JUMP: 520, WALK: 125, RUN: 205, CROUCH: 48, ACC: 1100,
    /* p: {x,y,vx,vy,onG,plat,face,crouch,coy,jbuf,z0,z1,landV}; ctl: {dir,run,crouch,jump}; env: {floorY,plats,lowG,locked} */
    step(p, dt, ctl, env) {
      let jumped = false, landed = 0;
      const target = env.locked ? 0 : ctl.dir * (p.crouch ? this.CROUCH : ctl.run ? this.RUN : this.WALK);
      const a = this.ACC * dt;
      p.vx = p.vx < target ? Math.min(target, p.vx + a) : Math.max(target, p.vx - a);
      if (!env.locked && ctl.dir) p.face = ctl.dir;
      p.crouch = !env.locked && p.onG && ctl.crouch;
      if (p.crouch) { p.vx = Math.max(-this.CROUCH, Math.min(this.CROUCH, p.vx)); }
      const prevY = p.y;
      // carried by moving platform
      if (p.onG && p.plat) { p.x += p.plat.dx; p.y = p.plat.top; }
      p.x += p.vx * dt;
      p.x = Math.max(p.z0 + 14, Math.min(p.z1 - 14, p.x));
      // stair step-up (small ledges) while grounded
      if (p.onG && p.vx !== 0) {
        for (const pl of env.plats) { if (!pl.active) continue; if (p.x > pl.x0 - 2 && p.x < pl.x1 + 2 && pl.top < p.y - 2 && pl.top > p.y - 30 && !pl.mv) { p.y = pl.top; p.plat = pl; } }
      }
      // jumping
      p.jbuf = ctl.jump ? Math.min(.14, (p.jbuf || 0) + dt) : 0;
      if (ctl.jumpPressed) p.jbuf = .14;
      p.coy = p.onG ? .1 : Math.max(0, p.coy - dt);
      if (!env.locked && p.jbuf > 0 && (p.onG || p.coy > 0) && !p.crouch) { p.vy = -this.JUMP; p.onG = false; p.plat = null; p.coy = 0; p.jbuf = 0; jumped = true; }
      // gravity
      const gr = this.GRAV * (env.lowG ? .34 : 1);
      if (!p.onG) { p.vy += gr * dt; p.y += p.vy * dt; }
      else if (p.plat && p.plat.active === false) { p.onG = false; p.plat = null; }
      // support check (grounded)
      if (p.onG) {
        let sup = p.y >= env.floorY - .5; if (sup) { p.y = env.floorY; p.plat = null; }
        else if (p.plat && p.x > p.plat.x0 - 4 && p.x < p.plat.x1 + 4 && p.plat.active) { p.y = p.plat.top; sup = true; }
        if (!sup) { p.onG = false; p.plat = null; }
      } else {
        let land = null;
        if (p.vy >= 0) for (const pl of env.plats) { if (!pl.active) continue; if (p.x > pl.x0 - 4 && p.x < pl.x1 + 4 && prevY <= pl.top + 6 + Math.abs(pl.dy) && p.y >= pl.top) { if (!land || pl.top < land.top) land = pl; } }
        if (land) { landed = p.vy; p.y = land.top; p.vy = 0; p.onG = true; p.plat = land; }
        else if (p.y >= env.floorY) { landed = p.vy; p.y = env.floorY; p.vy = 0; p.onG = true; p.plat = null; }
      }
      return { jumped, landed };
    },
    updatePlats(plats, t, floorY, prevT) {
      for (const pl of plats) {
        const m = pl.mv; const top0 = pl.top;
        if (m) { const cx = pl.cx + Math.sin(t * m.sp) * m.ax, cy = floorY - pl.hy + Math.sin(t * m.sp + 1.3) * (m.ay || 0); const px = (pl.x0 + pl.x1) / 2; pl.dx = cx - px; pl.dy = cy - top0; pl.x0 += pl.dx; pl.x1 += pl.dx; pl.top = cy; } else { pl.dx = 0; pl.dy = 0; }
      }
    }
  };
})(window);
