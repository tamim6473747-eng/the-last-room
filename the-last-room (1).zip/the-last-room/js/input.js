/* THE LAST ROOM - input manager (keyboard + multi-touch buttons) */
(function (g) {
  'use strict';
  const TLR = g.TLR = g.TLR || {};
  const keys = {}, touch = {}, handlers = {};
  const MAP = {
    ArrowLeft: 'left', KeyA: 'left', ArrowRight: 'right', KeyD: 'right',
    ArrowUp: 'jump', KeyW: 'jump', Space: 'jump',
    ArrowDown: 'crouch', KeyS: 'crouch', ShiftLeft: 'run', ShiftRight: 'run',
    KeyE: 'interact', Enter: 'interact', KeyI: 'inv', Tab: 'inv', KeyH: 'hint', KeyP: 'pause', Escape: 'pause', KeyQ: 'inv'
  };
  const Input = TLR.Input = {
    enabled: true,
    held(a) { return this.enabled && (!!keys[a] || !!touch[a]); },
    on(a, fn) { (handlers[a] = handlers[a] || []).push(fn); },
    fire(a) { (handlers[a] || []).forEach(f => f()); },
    clear() { for (const k in keys) keys[k] = false; for (const k in touch) touch[k] = false; document.querySelectorAll('#touch .tb.on').forEach(b => b.classList.remove('on')); },
    init() {
      addEventListener('keydown', e => {
        const a = MAP[e.code]; if (!a) return;
        if (e.target && /INPUT|TEXTAREA/.test(e.target.tagName)) return;
        if (a === 'jump' || e.code === 'Tab') e.preventDefault();
        if (!keys[a]) { keys[a] = true; if (!e.repeat) Input.fire(a); }
      });
      addEventListener('keyup', e => { const a = MAP[e.code]; if (a) keys[a] = false; });
      addEventListener('blur', () => Input.clear());
      document.addEventListener('visibilitychange', () => { if (document.hidden) Input.clear(); });
      const root = document.getElementById('touch');
      root.querySelectorAll('[data-act]').forEach(b => {
        const a = b.dataset.act;
        const down = e => { e.preventDefault(); try { b.setPointerCapture(e.pointerId); } catch (_) {} if (!touch[a]) { touch[a] = true; b.classList.add('on'); Input.fire(a); } };
        const up = e => { e.preventDefault(); touch[a] = false; b.classList.remove('on'); };
        b.addEventListener('pointerdown', down);
        b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('lostpointercapture', up);
        b.addEventListener('contextmenu', e => e.preventDefault());
      });
    }
  };
})(window);
