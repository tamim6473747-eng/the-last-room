/* THE LAST ROOM - boot */
(function (g) {
  'use strict';
  const TLR = g.TLR;
  function boot() {
    TLR.Save.init(); TLR.I18N.init(); TLR.Input.init(); TLR.Player.bake(); TLR.UI.init(); TLR.Game.init();
    const unlock = () => { TLR.Audio.init(); TLR.Audio.resume(); };
    ['pointerdown', 'keydown', 'touchstart'].forEach(e => addEventListener(e, unlock, { passive: true }));
    TLR.Game.mode = 'menu'; TLR.UI.menu();
    const q = location.search;
    if (/qa=1/.test(q)) { TLR.Game.qa = true; TLR.Puzzles.qa = true; }
    if (!(g.TLR_NO_SW) && 'serviceWorker' in navigator && location.protocol.indexOf('http') === 0) { navigator.serviceWorker.register('sw.js').catch(() => { }); }
    $('loading') && $('loading').remove();
  }
  function $(id) { return document.getElementById(id); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})(window);
