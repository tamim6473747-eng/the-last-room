THE LAST ROOM - Escape / Solve / Survive
Open index.html in any modern browser (Chrome on Android recommended, landscape). No install, no server, works offline.
Desktop: A/D or arrows move, Shift run, Space jump, S/Down crouch, E/Enter interact, I inventory, H hint, P/Esc pause.
Mobile: on-screen buttons (left/right, Jump, Crouch, Interact, Bag).
Structure: js/level-data.js = all 50 levels (data only); puzzle-engine.js = 14 puzzle types; scenery.js/props.js/player.js = all art (drawn with Canvas);
audio-manager.js = synthesized music/sfx. Self-test: open index.html?qa=1 and run TLR.Game.qaStep() in the console.

LANGUAGES
The game picks the device language automatically (Settings > Language can override it). Dictionaries live in js/lang-XX.js
(English is the source text; Bengali = js/lang-bn.js). To add a language, copy lang-bn.js, translate the values and load it in index.html + sw.js.
