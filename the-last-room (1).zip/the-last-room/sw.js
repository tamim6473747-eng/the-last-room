const C='tlr-v1',F=['./','index.html','style.css','js/save-system.js','js/i18n.js','js/lang-bn.js','js/audio-manager.js','js/input.js','js/art.js','js/scenery.js','js/props.js','js/player.js','js/physics.js','js/puzzle-engine.js','js/level-data.js','js/inventory.js','js/guide.js','js/story.js','js/ui.js','js/game.js','js/main.js'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(F))));
self.addEventListener('fetch',e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
